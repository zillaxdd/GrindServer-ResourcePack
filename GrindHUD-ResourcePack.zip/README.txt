GrindHUD v0.1.0. Original pixel assets; no vanilla textures or shaders replaced. Resource pack format 75.0.
https://www.minecraft.net/en-us/article/minecraft-java-edition-1-21-11
